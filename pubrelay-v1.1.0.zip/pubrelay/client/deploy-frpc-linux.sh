#!/bin/bash
# ============================================================
#  frpc 一键部署 (Linux) —— 客户端用
#
#  用法:
#    sudo SERVER_ADDR=1.2.3.4 TOKEN='xxxx' bash deploy-frpc-linux.sh
#
#  可选环境变量:
#    FRP_VERSION    frp 版本，默认 0.71.1
#    SERVER_ADDR    中转机公网地址（IP 或域名）
#    SERVER_PORT    控制通道端口，默认 7000
#    TOKEN          认证 token（必须和 frps 一致）
#    CONF_SRC       要安装的配置文件，默认 ../examples/frpc.toml
#    INSTALL_DIR    安装目录，默认 /opt/frp
# ============================================================
set -e

FRP_VERSION="${FRP_VERSION:-0.71.1}"
SERVER_ADDR="${SERVER_ADDR:-}"
SERVER_PORT="${SERVER_PORT:-7000}"
TOKEN="${TOKEN:-}"
INSTALL_DIR="${INSTALL_DIR:-/opt/frp}"
CONF_SRC="${CONF_SRC:-$(cd "$(dirname "$0")/.." && pwd)/examples/frpc.toml}"

[ "$(id -u)" -eq 0 ] || { echo "请用 root 运行: sudo bash $0"; exit 1; }

if [ -z "$SERVER_ADDR" ]; then
  echo "[!] 必须提供 SERVER_ADDR，例如："
  echo "    sudo SERVER_ADDR=1.2.3.4 TOKEN='xxx' bash $0"
  exit 1
fi
if [ -z "$TOKEN" ]; then
  echo "[!] 必须提供 TOKEN（和 frps.toml 里的 auth.token 一致）"
  exit 1
fi

# ---------- 架构 ----------
case "$(uname -m)" in
  x86_64|amd64)  ARCH=amd64 ;;
  aarch64|arm64) ARCH=arm64 ;;
  armv7l)        ARCH=arm ;;
  *) echo "不支持的架构: $(uname -m)"; exit 1 ;;
esac

PKG="frp_${FRP_VERSION}_linux_${ARCH}"
URL="https://github.com/fatedier/frp/releases/download/v${FRP_VERSION}/${PKG}.tar.gz"

echo "==> 1/4 准备 frpc 二进制"
mkdir -p "$INSTALL_DIR"
if [ -x "$INSTALL_DIR/frpc" ]; then
  echo "    已存在，跳过"
else
  TMP=$(mktemp -d)
  echo "    下载 $URL"
  if command -v curl >/dev/null 2>&1; then
    curl -fL --retry 3 -o "$TMP/frp.tar.gz" "$URL"
  else
    wget -qO "$TMP/frp.tar.gz" "$URL"
  fi
  tar -xzf "$TMP/frp.tar.gz" -C "$TMP"
  install -m 755 "$TMP/$PKG/frpc" "$INSTALL_DIR/frpc"
  rm -rf "$TMP"
  echo "    已安装"
fi

# ---------- 配置 ----------
echo "==> 2/4 生成配置"
CONF="$INSTALL_DIR/frpc.toml"
if [ -f "$CONF" ]; then
  echo "    $CONF 已存在，保留原配置"
else
  sed -e "s|^serverAddr = .*|serverAddr = \"${SERVER_ADDR}\"|" \
      -e "s|^serverPort = .*|serverPort = ${SERVER_PORT}|" \
      -e "s|^auth.token = .*|auth.token = \"${TOKEN}\"|" \
      -e "s|^log.to = .*|log.to = \"${INSTALL_DIR}/frpc.log\"|" \
      "$CONF_SRC" > "$CONF"
  chmod 600 "$CONF"
  echo "    已从模板生成 $CONF"

  # 模板里的示例端口只是占位，提示用户按需修改
  echo "    [i] 模板里有示例映射（nas-web 5667 / nas-ssh 15022），"
  echo "        请按实际情况修改 $CONF 后再重启服务。"
fi

# ---------- systemd ----------
echo "==> 3/4 注册服务"
cat > /etc/systemd/system/frpc.service <<UNIT
[Unit]
Description=frp client
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${INSTALL_DIR}/frpc -c ${CONF}
Restart=always
RestartSec=5
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable frpc >/dev/null 2>&1 || true

echo "==> 4/4 启动"
systemctl restart frpc
sleep 3
systemctl is-active frpc && echo "    frpc 运行中"
echo
echo "--- 最近日志 ---"
journalctl -u frpc -n 15 --no-pager -o cat || true
echo
echo "============================================================"
echo " 完成。改配置后请这样重启（直接 systemctl restart 会断掉当前 SSH）:"
echo "   systemd-run --no-block --unit=frpc-reload-\$(date +%s) systemctl restart frpc"
echo "============================================================"
