﻿# ============================================================
#  frps 一键部署 (Windows) —— 中转机用
#
#  用法（管理员 PowerShell）:
#    powershell -ExecutionPolicy Bypass -File deploy-frps-windows.ps1
#
#  可选参数:
#    -InstallDir  D:\frp          安装目录
#    -BindPort    7000            控制通道端口
#    -Token       "xxxx"          认证 token（不填自动生成）
#    -HardenPower                 顺带关掉睡眠/合盖休眠（笔记本做中转机时用）
#    -SkipDownload                目录里已有 frps.exe，跳过下载
# ============================================================
param(
    [string]$InstallDir = "$env:SystemDrive\frp",
    [int]$BindPort = 7000,
    [string]$Token = "",
    [switch]$HardenPower,
    [switch]$SkipDownload
)

$ErrorActionPreference = 'Stop'

function Info($m) { Write-Host "  $m" -ForegroundColor Gray }
function Ok($m)   { Write-Host "  $m" -ForegroundColor Green }
function Warn($m) { Write-Host "  $m" -ForegroundColor Yellow }

# ---------- 0. 管理员检查 ----------
$isAdmin = ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
if (-not $isAdmin) {
    Write-Host "请以管理员身份运行本脚本。" -ForegroundColor Red
    exit 1
}

Write-Host ""
Write-Host "=== frps 一键部署 (Windows) ===" -ForegroundColor Cyan
Write-Host "  安装目录 : $InstallDir"
Write-Host "  控制端口 : $BindPort"

if (-not $Token) {
    $chars = (48..57) + (65..90) + (97..122)
    $Token = -join ($chars | Get-Random -Count 32 | ForEach-Object { [char]$_ })
    Warn "未提供 Token，已生成: $Token"
}

# ---------- 1. 准备 frps.exe ----------
Write-Host ""
Write-Host "[1/6] 准备 frps.exe" -ForegroundColor Cyan
New-Item -ItemType Directory -Force -Path $InstallDir | Out-Null
$frpsExe = Join-Path $InstallDir 'frps.exe'

if (Test-Path $frpsExe) {
    Ok "已存在，跳过下载"
} elseif ($SkipDownload) {
    Warn "指定了 -SkipDownload 但 $frpsExe 不存在"
    exit 1
} else {
    $ver = '0.71.1'
    $arch = if ($env:PROCESSOR_ARCHITECTURE -eq 'ARM64') { 'arm64' } else { 'amd64' }
    $zipName = "frp_${ver}_windows_${arch}.zip"
    $url = "https://github.com/fatedier/frp/releases/download/v${ver}/${zipName}"
    $tmp = Join-Path $env:TEMP $zipName
    Info "下载 $url"
    try {
        [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
        Invoke-WebRequest -Uri $url -OutFile $tmp -UseBasicParsing -TimeoutSec 300
    } catch {
        Write-Host "  下载失败: $_" -ForegroundColor Red
        Write-Host "  请手动下载 $url 解压后把 frps.exe 放到 $InstallDir，再加 -SkipDownload 重跑。" -ForegroundColor Yellow
        exit 1
    }
    $ext = Join-Path $env:TEMP "frp_ext_$(Get-Random)"
    Expand-Archive -Path $tmp -DestinationPath $ext -Force
    $found = Get-ChildItem -Path $ext -Recurse -Filter 'frps.exe' | Select-Object -First 1
    if (-not $found) { Write-Host " 解压后找不到 frps.exe" -ForegroundColor Red; exit 1 }
    Copy-Item $found.FullName $frpsExe -Force
    Remove-Item $tmp, $ext -Recurse -Force -ErrorAction SilentlyContinue
    Ok "已安装到 $frpsExe"
}

# Defender 排除，否则 frps 可能被当成病毒删掉
try {
    Add-MpPreference -ExclusionPath $InstallDir -ErrorAction SilentlyContinue
    Ok "已添加 Defender 排除路径"
} catch {
    Warn "Defender 排除失败（可能没有 Defender），不影响使用"
}

# ---------- 2. 写配置 ----------
Write-Host ""
Write-Host "[2/6] 写配置" -ForegroundColor Cyan
$cfgPath = Join-Path $InstallDir 'frps.toml'
if (Test-Path $cfgPath) {
    Ok "已存在，保留原配置（删掉可重新生成）"
} else {
    $webPw = -join ((48..57) + (65..90) + (97..122) | Get-Random -Count 14 | ForEach-Object { [char]$_ })
    $cfg = @"
bindAddr = "0.0.0.0"
bindPort = $BindPort

auth.method = "token"
auth.token = "$Token"

# 允许客户端占用的公网端口。路由器端口转发 + 这里 = 双保险。
allowPorts = [
  { start = 5667,  end = 5667 },
  { start = 8090,  end = 8090 },
  { start = 2285,  end = 2285 },
  { start = 15000, end = 15100 },
  { start = 19132, end = 19134 },
  { start = 25565, end = 25570 },
]

# 管理面板：只监听本机
# 访问: ssh -L 7500:127.0.0.1:7500 user@本机
webServer.addr = "127.0.0.1"
webServer.port = 7500
webServer.user = "admin"
webServer.password = "$webPw"

log.to = "$($InstallDir -replace '\\','/')/frps.log"
log.level = "info"
log.maxDays = 7
"@
    [System.IO.File]::WriteAllText($cfgPath, $cfg, (New-Object System.Text.UTF8Encoding($false)))
    Ok "已生成 $cfgPath"
}

# 启动脚本
$batPath = Join-Path $InstallDir 'run_frps.bat'
if (-not (Test-Path $batPath)) {
    $bat = "@echo off`r`ncd /d `"%~dp0`"`r`n`"%~dp0frps.exe`" -c `"%~dp0frps.toml`"`r`n"
    [System.IO.File]::WriteAllText($batPath, $bat, [System.Text.Encoding]::ASCII)
    Ok "已生成 run_frps.bat"
}

# ---------- 3. 防火墙 ----------
Write-Host ""
Write-Host "[3/6] 防火墙放行 $BindPort/tcp" -ForegroundColor Cyan
try {
    if (-not (Get-NetFirewallRule -DisplayName "frps-$BindPort" -ErrorAction SilentlyContinue)) {
        New-NetFirewallRule -DisplayName "frps-$BindPort" -Direction Inbound -Protocol TCP -LocalPort $BindPort -Action Allow | Out-Null
        Ok "已创建入站规则"
    } else {
        Ok "规则已存在"
    }
} catch { Warn "防火墙规则创建失败: $_" }

# ---------- 4. 计划任务（开机自启 + SYSTEM） ----------
Write-Host ""
Write-Host "[4/6] 注册开机自启任务 frps-relay" -ForegroundColor Cyan
$act = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument "/c `"$batPath`"" -WorkingDirectory $InstallDir
$trg1 = New-ScheduledTaskTrigger -AtStartup
$trg2 = New-ScheduledTaskTrigger -AtLogOn
$pri = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -StartWhenAvailable -MultipleInstances IgnoreNew -ExecutionTimeLimit ([TimeSpan]::Zero) -RestartCount 999 -RestartInterval (New-TimeSpan -Minutes 1)
Register-ScheduledTask -TaskName 'frps-relay' -Action $act -Trigger @($trg1, $trg2) -Principal $pri -Settings $set -Force | Out-Null
Ok "已注册（SYSTEM 身份，不依赖登录；崩溃后 1 分钟重试）"

# ---------- 5. 看门狗 ----------
Write-Host ""
Write-Host "[5/6] 注册看门狗 frps-watchdog（每 5 分钟检查）" -ForegroundColor Cyan
$wdPath = Join-Path $InstallDir 'frps_watchdog.ps1'
$wd = @'
$proc = Get-Process frps -ErrorAction SilentlyContinue
if (-not $proc) {
    Start-ScheduledTask -TaskName 'frps-relay' -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 5
    $p2 = Get-Process frps -ErrorAction SilentlyContinue
    $status = 'FAILED'
    if ($p2) { $status = 'OK pid=' + $p2.Id }
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  frps missing -> restart: ' + $status
    Add-Content -LiteralPath (Join-Path $PSScriptRoot 'watchdog.log') -Value $line -Encoding utf8
}
'@
[System.IO.File]::WriteAllText($wdPath, $wd, (New-Object System.Text.UTF8Encoding($true)))
& schtasks /create /tn "frps-watchdog" /tr "powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File `"$wdPath`"" /sc minute /mo 5 /ru SYSTEM /rl HIGHEST /f | Out-Null
Ok "已注册（每 5 分钟）"

# ---------- 6. 电源加固（可选） ----------
Write-Host ""
if ($HardenPower) {
    Write-Host "[6/6] 电源加固（笔记本做中转机建议）" -ForegroundColor Cyan
    powercfg /change standby-timeout-ac 0
    powercfg /change standby-timeout-dc 0
    powercfg /change hibernate-timeout-ac 0
    powercfg /change disk-timeout-ac 0
    powercfg /change monitor-timeout-ac 15
    powercfg /setacvalueindex SCHEME_CURRENT 4f971e89-eebd-4455-a8de-9e59040e7347 5ca83367-6e45-459f-a27b-476b1d01c936 0
    powercfg /setdcvalueindex SCHEME_CURRENT 4f971e89-eebd-4455-a8de-9e59040e7347 5ca83367-6e45-459f-a27b-476b1d01c936 0
    powercfg /setactive SCHEME_CURRENT
    Ok "已关闭睡眠/休眠，合盖不采取操作，屏幕 15 分钟息屏"

    Set-Service w32time -StartupType Automatic -ErrorAction SilentlyContinue
    Start-Service w32time -ErrorAction SilentlyContinue
    & w32tm /config /manualpeerlist:"ntp.aliyun.com,0x8 time.windows.com,0x8" /syncfromflags:manual /reliable:yes /update | Out-Null
    Restart-Service w32time -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 2
    & w32tm /resync /rediscover | Out-Null
    Ok ("时间已校准: " + (Get-Date).ToString('yyyy-MM-dd HH:mm:ss'))

    Info "提醒：BIOS 里的 Restore on AC Power Loss 需手动设为 Power On，断电后才能自动开机"
} else {
    Write-Host "[6/6] 电源加固 - 已跳过（加 -HardenPower 参数启用）" -ForegroundColor DarkGray
}

# ---------- 7. 启动 ----------
Write-Host ""
Write-Host "[启动] frps" -ForegroundColor Cyan
$running = Get-Process frps -ErrorAction SilentlyContinue
if ($running) {
    Info "frps 已在运行 (pid=$($running.Id))，跳过启动"
} else {
    Start-ScheduledTask -TaskName 'frps-relay'
    Start-Sleep -Seconds 4
    $p = Get-Process frps -ErrorAction SilentlyContinue
    if ($p) { Ok "已启动 (pid=$($p.Id))" } else { Warn "启动后没检测到进程，请查看事件日志" }
}

$listen = (Get-NetTCPConnection -LocalPort $BindPort -State Listen -ErrorAction SilentlyContinue)
if ($listen) { Ok "$BindPort 端口正在监听" } else { Warn "$BindPort 端口没有监听，检查配置或日志" }

# ---------- 汇总 ----------
$pubToken = (Select-String -Path $cfgPath -Pattern '^auth\.token' -ErrorAction SilentlyContinue | Select-Object -First 1).Line
Write-Host ""
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " 部署完成" -ForegroundColor Cyan
Write-Host "============================================================" -ForegroundColor Cyan
Write-Host " 安装目录 : $InstallDir"
Write-Host " 配置文件 : $cfgPath"
Write-Host " 控制端口 : $BindPort"
Write-Host " Token    : $(($pubToken -split '"')[1])"
Write-Host " 日志     : $InstallDir\frps.log"
Write-Host " 看门狗   : $InstallDir\watchdog.log"
Write-Host ""
Write-Host " 下一步:" -ForegroundColor Yellow
Write-Host "   1) 路由器把 $BindPort/tcp 及其他要用的端口转发到本机"
Write-Host "   2) 客户端 serverAddr=<本机公网IP> serverPort=$BindPort"
Write-Host "   3) 客户端 auth.token 填上面的 Token"
Write-Host ""
