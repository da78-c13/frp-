#!/bin/bash
# ============================================================
#  frps 一键部署 (Linux) —— 中转机用
#
#  用法:
#    sudo bash deploy-frps-linux.sh
#    sudo FRP_TOKEN='你的token' BIND_PORT=7000 bash deploy-frps-linux.sh
#
#  可选环境变量:
#    FRP_VERSION    frp 版本，默认 0.71.1
#    BIND_PORT      控制通道端口，默认 7000
#    FRP_TOKEN      认证 token；不提供会自动生成
#    INSTALL_DIR    安装目录，默认 /opt/frp
# ============================================================
set -e

FRP_VERSION="${FRP_VERSION:-0.71.1}"
BIND_PORT="${BIND_PORT:-7000}"
INSTALL_DIR="${INSTALL_DIR:-/opt/frp}"
FRP_TOKEN="${FRP_TOKEN:-}"

[ "$(id -u)" -eq 0 ] || { echo "请用 root 运行: sudo bash $0"; exit 1; }

if [ -z "$FRP_TOKEN" ]; then
  FRP_TOKEN=$(head -c 24 /dev/urandom | base64 | tr -d '/+=' | head -c 32)
  echo "[i] 未提供 FRP_TOKEN，已生成: $FRP_TOKEN"
fi

# ---------- 1. 判断架构 ----------
case "$(uname -m)" in
  x86_64|amd64)  ARCH=amd64 ;;
  aarch64|arm64) ARCH=arm64 ;;
  armv7l)        ARCH=arm ;;
  *) echo "不支持的架构: $(uname -m)"; exit 1 ;;
esac

PKG="frp_${FRP_VERSION}_linux_${ARCH}"
URL="https://github.com/fatedier/frp/releases/download/v${FRP_VERSION}/${PKG}.tar.gz"

echo "==> 1/5 准备 frps 二进制 (${ARCH})"
mkdir -p "$INSTALL_DIR"
if [ -x "$INSTALL_DIR/frps" ]; then
  echo "    已存在，跳过下载（删掉 $INSTALL_DIR/frps 可强制重下）"
else
  TMP=$(mktemp -d)
  echo "    下载 $URL"
  if command -v curl >/dev/null 2>&1; then
    curl -fL --retry 3 -o "$TMP/frp.tar.gz" "$URL"
  else
    wget -qO "$TMP/frp.tar.gz" "$URL"
  fi
  tar -xzf "$TMP/frp.tar.gz" -C "$TMP"
  install -m 755 "$TMP/$PKG/frps" "$INSTALL_DIR/frps"
  rm -rf "$TMP"
  echo "    已安装到 $INSTALL_DIR/frps"
fi

# ---------- 2. 写配置（已存在则不覆盖） ----------
echo "==> 2/5 写配置"
if [ -f "$INSTALL_DIR/frps.toml" ]; then
  echo "    $INSTALL_DIR/frps.toml 已存在，保留原配置"
else
  cat > "$INSTALL_DIR/frps.toml" <<CONF
bindAddr = "0.0.0.0"
bindPort = ${BIND_PORT}

auth.method = "token"
auth.token = "${FRP_TOKEN}"

# 允许客户端占用的公网端口。
# 路由器端口转发 + 这里的白名单 = 双保险，至少配一道。
allowPorts = [
  { start = 5667,  end = 5667 },
  { start = 8090,  end = 8090 },
  { start = 2285,  end = 2285 },
  { start = 15000, end = 15100 },
  { start = 19132, end = 19134 },
  { start = 25565, end = 25570 },
]

# 管理面板：只监听本机，绝不暴露公网
webServer.addr = "127.0.0.1"
webServer.port = 7500
webServer.user = "admin"
webServer.password = "$(head -c 18 /dev/urandom | base64 | tr -d '/+=' | head -c 12)"

log.to = "${INSTALL_DIR}/frps.log"
log.level = "info"
log.maxDays = 7
CONF
  chmod 600 "$INSTALL_DIR/frps.toml"
  echo "    已生成 $INSTALL_DIR/frps.toml"
fi

# ---------- 3. systemd ----------
echo "==> 3/5 注册 systemd 服务"
cat > /etc/systemd/system/frps.service <<UNIT
[Unit]
Description=frp server
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=${INSTALL_DIR}/frps -c ${INSTALL_DIR}/frps.toml
Restart=always
RestartSec=5
LimitNOFILE=1048576

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable frps >/dev/null 2>&1 || true

# ---------- 4. 防火墙 ----------
echo "==> 4/5 防火墙放行 ${BIND_PORT}/tcp"
if command -v ufw >/dev/null 2>&1 && ufw status 2>/dev/null | grep -q "Status: active"; then
  ufw allow "${BIND_PORT}"/tcp >/dev/null 2>&1 && echo "    ufw: 已放行"
elif command -v firewall-cmd >/dev/null 2>&1 && firewall-cmd --state >/dev/null 2>&1; then
  firewall-cmd --permanent --add-port="${BIND_PORT}/tcp" >/dev/null 2>&1
  firewall-cmd --reload >/dev/null 2>&1 && echo "    firewalld: 已放行"
else
  echo "    未检测到活动防火墙，跳过"
fi

# ---------- 5. 启动 ----------
echo "==> 5/5 启动"
systemctl restart frps
sleep 2
systemctl is-active frps && echo "    frps 运行中"

echo
echo "============================================================"
echo " 部署完成"
echo " 控制通道 : 0.0.0.0:${BIND_PORT}"
echo " token    : ${FRP_TOKEN}"
echo " 配置文件 : ${INSTALL_DIR}/frps.toml"
echo " 日志     : journalctl -u frps -f"
echo
echo " 下一步："
echo "   1) 路由器把 ${BIND_PORT}/tcp 以及其他要用的端口转发到本机"
echo "   2) 客户端填 serverAddr=<本机公网IP> serverPort=${BIND_PORT}"
echo "   3) 客户端 auth.token 填上面这个 token"
echo "============================================================"
