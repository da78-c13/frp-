﻿# ============================================================
#  frps 看门狗 —— 每 5 分钟检查一次进程，挂了就拉起
#
#  说明：deploy-frps-windows.ps1 会自动生成这个文件并注册任务，
#  一般不需要手动部署。单独使用时会写到同目录的 watchdog.log。
# ============================================================

$proc = Get-Process frps -ErrorAction SilentlyContinue
if (-not $proc) {
    Start-ScheduledTask -TaskName 'frps-relay' -ErrorAction SilentlyContinue
    Start-Sleep -Seconds 5
    $p2 = Get-Process frps -ErrorAction SilentlyContinue
    $status = 'FAILED'
    if ($p2) { $status = 'OK pid=' + $p2.Id }
    $line = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss') + '  frps missing -> restart: ' + $status
    Add-Content -LiteralPath (Join-Path $PSScriptRoot 'watchdog.log') -Value $line -Encoding utf8
}
