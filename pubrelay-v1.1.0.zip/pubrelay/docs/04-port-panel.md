# 04 · Web 端口管理面板

改 frpc 配置的体验有多糟：

1. SSH 上去
2. `sudo vim /etc/frp/frpc.toml`
3. 照着格式抄一段 `[[proxies]]`
4. 保存，`systemctl restart frpc`
5. **SSH 断了**（因为隧道就是自己），还得重连
6. 端口冲突了，重来一遍

所以写了这个面板。**单文件、零依赖、一个网页**。

---

## 一、能力

| 功能 | 说明 |
|---|---|
| 列出全部映射 | 已启用的显示端口、协议、名称；被注释掉显示为"已停用"，仍可一键恢复 |
| 新增映射 | 填本地端口 / 公网端口 / 名称 / 协议（TCP·UDP），点一下生效 |
| 删除映射 | 每条后面的 ✕ |
| 停用 / 启用 | 停用是**注释掉整块配置**，不是删除，随时可恢复 |
| 端口扫描 | 实时列出本机正在监听的端口 + 进程名，未映射的直接点 `+` 建映射 |
| MC 一键开启 | 一键给 Java 版（TCP 25565/25566）+ 基岩版（UDP 19132/19133）建映射 |

---

## 二、部署

```bash
cd panel
sudo PANEL_PASSWORD='你的强口令' bash deploy.sh
```

可选参数：

| 环境变量 | 默认 | 说明 |
|---|---|---|
| `PANEL_PORT` | 2285 | 面板监听端口 |
| `PANEL_PASSWORD` | 随机生成 | 登录口令 |
| `PANEL_FRPC_CONF` | `/etc/frp/frpc.toml` | 要管理的配置文件 |
| `PANEL_SERVICE` | `frpc` | 要重启的 systemd 服务名 |
| `SKIP_FRP_MAP` | `0` | 设 `1` 则不加面板自身的公网映射 |

脚本会自动：

1. 装到 `/opt/portpanel/`
2. 写 `portpanel.service`（root 运行、开机自启、崩溃重拉）
3. 往 frpc.toml 追加面板自己的映射（幂等，不会重复加）
4. 异步重启 frpc（不掐断你的 SSH）

装完访问 `http://<本机IP>:2285`。

### 手动部署（不想用脚本）

```bash
sudo install -m 755 app.py /opt/portpanel/app.py
sudo cp portpanel.service /etc/systemd/system/
sudo systemctl daemon-reload && sudo systemctl enable --now portpanel
```

---

## 三、安全设计

面板本身是**root 权限的公网 Web 应用**，所以内置了几层防护：

### 1. 高危端口黑名单

| 端口 | 拒绝理由 |
|---|---|
| 21 | FTP 明文口令 |
| 23 | Telnet 明文 |
| 111 | rpcbind 信息泄露 |
| 139 / 445 | SMB，勒索病毒首选目标 |
| 2049 | NFS 无认证 |
| 3306 / 5432 | MySQL / PostgreSQL 裸奔 |
| 6379 | Redis 默认无认证 |
| 7890 | Clash 代理会被滥用 |
| 3702 | wsdd2 组播 |

添加这些端口会被直接拒绝，连配置都不写。

### 2. 自身通道保护

面板自己走的那条映射**不允许删除**，防止手滑把自己关了再也进不去。

### 3. 自动备份

每次改配置前备份到 `frpc.toml.bak.<时间戳>`，最多保留 20 份。改坏了随时回滚：

```bash
sudo cp /etc/frp/frpc.toml.bak.1730000000 /etc/frp/frpc.toml
sudo systemctl restart frpc
```

### 4. 行级编辑，不重排你的配置

不是 `yaml.dump()` 那种"读进来再吐出去"的做法——那样会把你辛苦写的中文注释、分组、空行全部抹掉。面板只在文本层面插入/注释/删除对应行，其余内容原样保留。

### 5. 口令登录

- 口令通过环境变量注入，不写在代码里
- 没设环境变量就随机生成一个打到日志里，杜绝"默认口令"被扫
- Cookie 是 `HttpOnly` + `SameSite=Lax`，值是 `HMAC(口令)`
- 登录失败有延迟，防暴力破解

---

## 四、降低权限（可选）

面板以 root 运行是为了 `systemctl restart frpc` 和读写 `/etc/frp`。如果你觉得不合适，可以换成：

```bash
# 建一个专用用户，只给它 frpc 的重启权限
sudo useradd -r -s /usr/sbin/nologin portpanel
sudo chown portpanel:portpanel /etc/frp/frpc.toml
sudo tee /etc/sudoers.d/portpanel > /dev/null <<'EOF'
portpanel ALL=(root) NOPASSWD: /bin/systemctl restart frpc
EOF
```

然后改 unit 里的 `User=portpanel`。

不过说实话，面板能改的就是 frpc 配置，而能改 frpc 配置的人本来就能把任意端口转发出去——**权限收窄带来的实际收益有限**，重要的是别让面板本身暴露在无口令状态。

---

## 五、一个已知现象

每次点"添加"或"删除"，frpc 会重启一次，**公网会短暂断开 1~3 秒**。

这是 frp 的机制决定的（改配置必须重启进程）。面板会在前端延迟 1.5~2 秒再刷新，让用户感知不到失败。如果你正在用公网连接做别的事，避免在这个时间点操作。

想彻底避免，得换 frp 的 `frpc reload` 热加载：

```bash
frpc reload -c /etc/frp/frpc.toml
```

但热加载对**新增**代理的支持不如重启可靠（老版本有 bug），而且 `allowPorts` 变更不一定生效。改动频繁的话可以试试，稳定优先就保持重启。

---

## 六、界面

```
┌─────────────────────────────────────────────────────────────┐
│  Port Panel                          frpc ● running   退出  │
├─────────────────────────────────────────────────────────────┤
│  Minecraft 联机                                              │
│  一键开启 Java 版 (TCP 25565/25566) 和基岩版 (UDP 19132/19133) │
│  [ 一键开启 MC 端口 ]                                        │
├─────────────────────────────────────────────────────────────┤
│  新增映射                                                    │
│  本地端口 [____]  公网端口 [____]  名称 [________]           │
│  协议 [TCP ▾]                            [ 添加并生效 ]      │
├─────────────────────────────────────────────────────────────┤
│  当前映射 (18)                                               │
│  TCP · 本地 5667  → 公网 5667     nas-web              ✕     │
│  TCP · 本地 22    → 公网 15022    nas-ssh              ✕     │
│  UDP · 本地 19132 → 公网 19132    mc-bedrock           ✕     │
│                                                              │
│  已停用 (5)                                                  │
│  TCP · 本地 5432  → 公网 5432     pg-disabled    [启用]      │
├─────────────────────────────────────────────────────────────┤
│  监听端口扫描 (45)                                           │
│  5667  fnOS      已映射                                      │
│  8090  python3   未映射  [+]                                 │
│  2284  upsnap    未映射  [+]                                 │
└─────────────────────────────────────────────────────────────┘
```

---

## 七、不用面板，纯命令行怎么做

面板只是把下面这些操作图形化了。你也可以直接改文件：

```bash
# 新增
cat >> /etc/frp/frpc.toml <<'EOF'

[[proxies]]
name = "my-service"
type = "tcp"
localIP = "127.0.0.1"
localPort = 8080
remotePort = 8080
EOF

# 停用（注释整块）
sed -i '/name = "my-service"/,+5 s/^/#/' /etc/frp/frpc.toml

# 异步重启（关键：别用 systemctl restart，会断自己的 SSH）
systemd-run --no-block --unit=frpc-reload systemctl restart frpc
```

`sed` 里的 `+5` 是第一行后面再跟 5 行，对应 `name/type/localIP/localPort/remotePort` 五句。
