# 02 · 中转机部署（frps）

中转机的要求只有一条：**有一个能用的公网 IPv4**。

可以是云服务器、公司/学校的机器、朋友家的宽带（如果有公网 IP）。配置越低越好，frps 基本不吃资源，1 核 512M 足够。

---

## 一、拿到 frp

从 [github.com/fatedier/frp/releases](https://github.com/fatedier/frp/releases) 下载对应平台的包。本仓库样例基于 **v0.71.1**。

```bash
# Linux x86_64
wget https://github.com/fatedier/frp/releases/download/v0.71.1/frp_0.71.1_linux_amd64.tar.gz
tar -xzf frp_0.71.1_linux_amd64.tar.gz
cd frp_0.71.1_linux_amd64
```

只需要 `frps` 和 `frps.toml` 两个文件。

> Windows 上如果被 Defender 拦截，把 frps.exe 所在目录加进排除项：
> `Add-MpPreference -ExclusionPath "D:\frp"`

---

## 二、写配置

`frps.toml`：

```toml
bindAddr = "0.0.0.0"
bindPort = 7000              # 控制通道，路由器要转发这个端口

auth.method = "token"
auth.token = "换成一串足够长的随机字符"   # 客户端必须一致

# 允许客户端占用的公网端口范围。
# 不写 = 不限制，风险很高（见 05-security.md）
allowPorts = [
  { start = 5667,  end = 5667 },      # NAS 管理页
  { start = 8090,  end = 8090 },      # 某个 Web 服务
  { start = 15000, end = 15100 }      # 一段高位端口，给 SSH 等用
]

# 管理面板：只监听本机，绝不暴露到公网
webServer.addr = "127.0.0.1"
webServer.port = 7500
webServer.user = "admin"
webServer.password = "换一个强口令"

log.to = "frps.log"
log.level = "info"
log.maxDays = 7
```

### token 怎么生成

```bash
# Linux / macOS
head -c 24 /dev/urandom | base64 | tr -d '/+=' | head -c 32; echo

# Windows PowerShell
-join ((48..57) + (65..90) + (97..122) | Get-Random -Count 32 | % {[char]$_})
```

### 关于 `allowPorts`

这是**最重要的一行安全配置**。它决定了客户端能占用哪些公网端口。

- 如果你把路由器设成"TCP 全端口转发"，**必须**写 `allowPorts`，否则任何拿到 token 的人都能在你机器上开任意端口
- 如果你已经把路由器端口转发收窄到具体几个端口，`allowPorts` 可以省略（此时路由器就是第二道锁）

客户端实际能开放的端口 = `allowPorts` ∩ 路由器转发端口。**两道锁任意一道生效就够**，但都配上更稳。

### 关于 `bindPort`

默认 7000。如果你的中转机在校园网/公司网络，7000 被墙的可能性不低，可以改成 443 或 8443 这种"看起来像正常流量"的端口——frp 走的是普通 TLS 外观的 TCP，放在 443 上一般不会被拦。

---

## 三、一键部署

### Linux

```bash
sudo bash server/deploy-frps-linux.sh
```

脚本会：

1. 把 `frps` 和 `frps.toml` 放到 `/opt/frp/`
2. 生成 `frps.service`，注册开机自启
3. 启动服务并打印状态

手动的话就三步：

```bash
sudo mkdir -p /opt/frp
sudo cp frps frps.toml /opt/frp/
sudo tee /etc/systemd/system/frps.service > /dev/null <<'EOF'
[Unit]
Description=frp server
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
ExecStart=/opt/frp/frps -c /opt/frp/frps.toml
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
EOF
sudo systemctl daemon-reload
sudo systemctl enable --now frps
```

### Windows

```powershell
# 管理员 PowerShell
powershell -ExecutionPolicy Bypass -File server\deploy-frps-windows.ps1
```

Windows 版多做了三件事，因为 Windows 上"开机自启"比 Linux 坑多：

1. **计划任务以 SYSTEM 身份运行**，不依赖有人登录
2. **看门狗**每 5 分钟检查一次进程，挂了自动拉起
3. **关掉电池/睡眠导致的停止**（笔记本做中转机必须）

> 为什么不注册成 Windows 服务？因为 frps.exe 是控制台程序，不是服务程序，`sc create` 会报 1053 错误。要用 winsw / nssm 包一层才行，反而更复杂。计划任务 + SYSTEM + 看门狗的组合已经足够稳。

---

## 四、路由器：把端口送到中转机

登录路由器后台，找"端口转发 / 虚拟服务器 / NAT"：

| 外部端口 | 内部 IP | 内部端口 | 协议 |
|---|---|---|---|
| 7000 | 中转机内网 IP | 7000 | TCP |
| 5667 | 中转机内网 IP | 5667 | TCP |
| 8090 | 中转机内网 IP | 8090 | TCP |

三个要点：

1. **中转机的内网 IP 要固定**（静态 IP 或 DHCP 保留），否则重启后 IP 变了转发就失效
2. **UDP 服务要单独加 UDP 规则**（Minecraft 基岩版、游戏服务器常见）
3. 别图省事写"TCP 1-65535 全转发"——除非你同时在 frps 里配了 `allowPorts`

改完用外部网络测一下：

```bash
# 在另一个网络环境（比如手机热点）执行
nc -vz 你的公网IP 7000
```

---

## 五、验证

```bash
# 1. frps 进程在跑吗
systemctl status frps          # Linux
Get-Process frps               # Windows

# 2. 7000 在监听吗
ss -tlnp | grep 7000           # Linux
netstat -ano | findstr :7000   # Windows

# 3. 客户端连上了吗（看 frps 日志）
tail -f /opt/frp/frps.log
# 正常会看到：
#   [nas] login to server success, get run id [...]
#   [nas] start proxy success
```

`login to server success` = 隧道建立了。`start proxy success` = 具体端口映射生效了。

---

## 六、保活：让中转机 7×24 不挂

中转机是整个方案的单点故障，必须做保活。三件事：

### 1. 进程看门狗

frps 偶尔会因为网络抖动异常退出。看门狗每 5 分钟检查一次，挂了就拉起来。

Linux 的在 `systemd` 里已经有 `Restart=always`，不用额外做。
Windows 用 `server\frps-watchdog.ps1`，部署脚本会自动注册。

### 2. 定时重启

Windows 长期运行后内存碎片、网络栈异常、句柄泄漏都可能让 frps 假死（进程在、但不转发）。每天凌晨重启一次最省心：

```powershell
$act = New-ScheduledTaskAction -Execute 'shutdown.exe' -Argument '/r /t 60 /c "每日计划重启"'
$trg = New-ScheduledTaskTrigger -Daily -At '03:00'
$pri = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries
Register-ScheduledTask -TaskName 'DailyReboot' -Action $act -Trigger $trg -Principal $pri -Settings $set -Force
```

### 3. Windows 时间必须准

**这一条被严重低估。** 我们实测遇到过：笔记本时区设置是 `China Standard Time` 看起来没问题，但**系统时钟本身偏了 8 小时**（`w32time` 服务是 `Stopped`，从来没同步过）。

后果是计划任务全部错位——设的"凌晨 3 点重启"实际会在**上午 11 点**执行，正好打断上班时间的传输。

检查：

```powershell
tzutil /g                        # 时区
(Get-Date).ToString('HH:mm')     # 把输出和手机比一下
Get-Service w32time              # 必须是 Running
```

修复：

```powershell
Set-Service w32time -StartupType Automatic
Start-Service w32time
w32tm /config /manualpeerlist:"ntp.aliyun.com,0x8 time.windows.com,0x8" /syncfromflags:manual /reliable:yes /update
Restart-Service w32time
w32tm /resync /rediscover
```

### 4. 断电后自动开机

BIOS 里的 `Restore on AC Power Loss`（不同主板叫法不同：`Power On After Power Failure` / `AC Back`）设成 `Power On`。这个只能进 BIOS 改，系统里改不了。

没有这一项，家里停一次电就得人工去按电源键。

### 5. 笔记本做中转机的额外注意

- **合盖不能睡眠**：`powercfg /q SCHEME_CURRENT SUB_BUTTONS SUB_BUTTON_ACTION_LID`，设成 `不采取任何操作`
  ```powershell
  powercfg /setacvalueindex SCHEME_CURRENT 4f971e89-eebd-4455-a8de-9e59040e7347 5ca83367-6e45-459f-a27b-476b1d01c936 0
  powercfg /setdcvalueindex SCHEME_CURRENT 4f971e89-eebd-4455-a8de-9e59040e7347 5ca83367-6e45-459f-a27b-476b1d01c936 0
  powercfg /setactive SCHEME_CURRENT
  ```
- **关闭睡眠**：`powercfg /change standby-timeout-ac 0`
- **关闭休眠和快速启动**：`powercfg /h off`（快速启动会让服务状态异常）
- **电池保护**：长期插电满电存放，电池一两年就鼓包。用厂商工具（联想 Vantage / 华硕 MyASUS）把充电阈值设成 60~80%
- **优先有线**：Wi-Fi 在信号波动时会瞬断，frp 会重连但中间有 5~10 秒空窗。有条件就插网线

---

## 七、常见错误

| 现象 | 原因 | 解决 |
|---|---|---|
| `connect: connection refused` | 客户端连到了错误地址 | 见下方"DDNS 陷阱" |
| `token in login doesn't match` | 两边 token 不一致 | 逐字符比对，注意首尾空格 |
| `port already used` | 公网端口被别的客户端占了 | 换端口，或检查是否重复配置 |
| `port not allowed` | 端口不在 `allowPorts` 范围内 | 改 `allowPorts` 或让客户端换端口 |
| 客户端显示 `login success` 但端口连不上 | 路由器没转发 / 防火墙拦截 | 检查路由器规则和本机防火墙 |
| 延迟忽高忽低 | 中转机带宽打满 | 限速或换机器 |

### DDNS 陷阱（真实踩坑）

如果你用脚本自动更新域名的 A 记录，**开着代理软件时千万小心**。

我们遇到过：机器上跑着 Clash TUN 模式，DDNS 脚本请求"查我的公网 IP"的接口时被代理接管，拿回来的是**代理出口 IP**（`45.129.x.x`），被写进了 A 记录。

结果：客户端按域名连过去，连到一台完全不相干的代理机上，报 `connection refused`。排查了两小时。

防御措施：

1. 用**国内**回显源：`ip.3322.net`、`myip.ipip.net`、`ddns.oray.com/checkip`
2. 或者干脆**写死 IP**，别用 DDNS（云服务器的 IP 一般不会变）
3. 在代理软件里加规则：`DOMAIN-SUFFIX,你的域名,DIRECT`
