# 03 · 客户端部署（frpc）

客户端是**要暴露出去的那台内网设备**。它在家里，主动连出去。

---

## 一、配置

`frpc.toml`：

```toml
# 中转机的公网地址
serverAddr = "你的中转机IP"     # 强烈建议直接写 IP
serverPort = 7000

auth.method = "token"
auth.token = "和中转机 frps.toml 里完全一致"

# 日志
log.to = "/var/log/frpc.log"
log.level = "info"
log.maxDays = 7

[[proxies]]
name = "nas-web"
type = "tcp"
localIP = "127.0.0.1"
localPort = 5667      # 本机服务真实端口
remotePort = 5667     # 公网访问用的端口，要和本地一致最省心

[[proxies]]
name = "nas-ssh"
type = "tcp"
localIP = "127.0.0.1"
localPort = 22
remotePort = 15022    # 不占用公网 22，避免和中转机自己的 SSH 冲突
```

### 为什么 `serverAddr` 要写 IP 不写域名

两个原因：

1. **避开 DNS 解析失败**（中转机 IP 变了、DNS 没生效、本地 DNS 污染）
2. **避开代理软件劫持**：如果客户端机器上跑着 Clash / V2Ray，域名可能被解析成 `198.18.0.x` 这种 fake-ip，连接直接被丢掉

如果非要用域名，就在代理软件里加一条 `DOMAIN-SUFFIX,你的域名,DIRECT`。

### `localPort` 和 `remotePort`

```
[[proxies]]
localPort  = 5667     ← NAS 上实际跑服务的端口
remotePort = 5667     ← 公网访问 `你的域名:5667`
```

两者相同最直观，但**不是必须相同**。远程端口冲突时改 `remotePort` 就行：

```
localPort  = 22        ← 本机 SSH 是 22
remotePort = 15022     ← 公网访问 `ssh -p 15022 你的域名`
```

### 一定要开 UDP 就别漏了 type

```toml
[[proxies]]
name = "mc-bedrock"
type = "udp"          # 基岩版是 UDP
localPort = 19132
remotePort = 19132
```

TCP 和 UDP 是两套独立的端口空间，**同一个端口号可以同时存在一条 TCP 和一条 UDP**，不冲突。

> 注意：`type = "udp"` 的映射在面板和日志里表现和 TCP 不同——UDP 是无连接的，不会有"连接成功"的日志，只能靠实际发包验证是通的还是不通的。

---

## 二、部署

### 通用 Linux / fnOS / 群晖（有 SSH）

```bash
sudo bash client/deploy-frpc-linux.sh
```

脚本做的事：

1. 下载对应架构的 frpc
2. 从 `examples/frpc.toml` 复制配置到 `/etc/frp/frpc.toml`（已存在则**不覆盖**）
3. 注册 `frpc.service`，开机自启
4. 启动并打印日志

手动：

```bash
sudo mkdir -p /etc/frp
sudo cp frpc /etc/frp/
sudo cp frpc.toml /etc/frp/
sudo cp client/frpc.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable --now frpc
```

### Docker

```yaml
services:
  frpc:
    image: snowdreamtech/frpc:latest
    container_name: frpc
    restart: unless-stopped
    network_mode: host          # 必须，否则访问不到宿主机服务
    volumes:
      - ./frpc.toml:/etc/frp/frpc.toml:ro
```

`network_mode: host` 是重点。用 bridge 网络的话，`localIP = 127.0.0.1` 指向的是容器自己，不是宿主机。

### Windows 客户端

和 Windows 服务端一样用计划任务：

```powershell
$dir = 'D:\frp'
$act = New-ScheduledTaskAction -Execute 'cmd.exe' -Argument '/c "D:\frp\run_frpc.bat"'
$trg = New-ScheduledTaskTrigger -AtStartup
$pri = New-ScheduledTaskPrincipal -UserId 'SYSTEM' -LogonType ServiceAccount -RunLevel Highest
$set = New-ScheduledTaskSettingsSet -AllowStartIfOnBatteries -DontStopIfGoingOnBatteries -ExecutionTimeLimit ([TimeSpan]::Zero)
Register-ScheduledTask -TaskName 'frpc-relay' -Action $act -Trigger $trg -Principal $pri -Settings $set -Force
```

`run_frpc.bat`：

```bat
@echo off
cd /d "%~dp0"
"%~dp0frpc.exe" -c "%~dp0frpc.toml"
```

---

## 三、改配置后怎么重启

**这一步有坑，而且是致命的那种。**

如果你通过 frp 隧道 SSH 登录客户端，然后执行：

```bash
sudo systemctl restart frpc     # ❌ 会把自己踢掉
```

`systemctl restart` 会先 kill 掉当前 frpc 进程，隧道瞬间消失，**你的 SSH 会话跟着断**，后面的启动命令可能根本没执行到。结果就是：隧道断了，服务也没起来。

正确做法是把重启操作脱离当前会话：

```bash
sudo systemd-run --no-block --unit=frpc-reload-$(date +%s) systemctl restart frpc
```

`systemd-run` 会在一个独立单元里执行重启，不受你的 SSH 会话生死影响。SSH 会断 1~3 秒，然后自动恢复（如果客户端配置了 `ServerAliveInterval`）。

或者更省事：用端口管理面板（`panel/`），它会自动处理这个细节。

---

## 四、验证

```bash
# 客户端侧：隧道建立了吗
sudo journalctl -u frpc -n 20 --no-pager
# 正常输出：
#   [nas-web] start proxy success
#   [nas-ssh] start proxy success

# 客户端侧：本机服务真的在监听吗
ss -tlnp | grep 5667

# 中转机侧：端口在监听吗
ss -tlnp | grep 5667

# 外部网络（手机热点）：
curl -v http://中转机IP:5667
```

排错顺序永远是：**本机服务 → 客户端 frpc → 隧道 → frps → 路由器 → 公网**。从里往外一层层查，不要跳。

---

## 五、一个实用技巧：只暴露必要端口

NAS 上通常跑着二三十个服务，全暴露出去风险很大。判断标准：

| 该暴露 | 不该暴露 |
|---|---|
| Web 界面（有登录页的） | 数据库（3306 / 5432 / 6379 / 27017） |
| SSH（改高位端口 + 密钥登录） | SMB / NFS（445 / 2049） |
| 游戏服务器 | Docker socket |
| 监控面板（有鉴权的） | frps 自己的管理面板 |

尤其注意：**数据库绝对不能暴露到公网**。这不是"密码够强就没事"的问题——扫描器每天扫全网，一旦被盯上就是密码爆破 + 数据泄露。
