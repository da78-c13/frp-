# 05 · 安全清单

这套方案的本质是：**把你内网的服务，搬到公网上**。

方便是方便，但互联网上每天都有扫描器在扫全端口。这一页列的东西，请至少过一遍。

---

## 一、必须做的六条

### 1. token 必须强随机

`auth.token` 一旦泄露，任何人在任何地方都能把你的中转机当跳板——他不需要你的服务器权限，只要连上 frps 就能开端口。

```bash
# 生成
head -c 24 /dev/urandom | base64 | tr -d '/+=' | head -c 32
```

不要用 `123456`、`frp123`、`password`。这些在字典里排第一。

### 2. frps 管理面板绝不暴露

```toml
webServer.addr = "127.0.0.1"    # ✅ 只监听本机
webServer.addr = "0.0.0.0"      # ❌ 等于把控制权挂到公网
```

要看就 SSH 隧道过去：

```bash
ssh -L 7500:127.0.0.1:7500 user@中转机
# 然后本地浏览器开 http://127.0.0.1:7500
```

### 3. 数据库绝对不要开

MySQL 3306、PostgreSQL 5432、Redis 6379、MongoDB 27017、Elasticsearch 9200。

这些服务的设计前提是"跑在可信内网"。Redis 至今默认没有密码，MongoDB 早年默认允许匿名访问。开出去等于把数据库送给扫描器。

面板里这些端口都在黑名单上，但**直接改配置文件可以绕过黑名单**——能不能守住全靠你。

如果确实需要远程访问数据库，用 SSH 隧道，或者上 WireGuard / Tailscale。

### 4. SSH 改成高位端口 + 只允许密钥

```toml
[[proxies]]
name = "nas-ssh"
localPort = 22
remotePort = 15022     # 别用 22
```

同时在客户端 `sshd_config` 里：

```
PasswordAuthentication no
PubkeyAuthentication yes
PermitRootLogin no
```

公网 22 端口每天被爆破几千次的量级，改端口能挡掉 99% 的自动化脚本。

### 5. 路由器端口转发要收窄

全端口转发（`TCP 1-65535 → 中转机`）看起来省事，实际上把安全性完全押在 frps 的 `allowPorts` 上。双保险的做法：

- 路由器只转发：`7000`（控制通道）+ 你实际要用的几个端口
- frps 的 `allowPorts` 再限一次

两道锁任意一道生效就够，但只上一道的话，那道锁就是唯一的命门。

### 6. 别用 HTTP 传密码

如果暴露的是 HTTP 服务（不是 HTTPS），登录密码是**明文过公网**的。

三层解法，从易到难：

| 方案 | 做法 |
|---|---|
| 套一层 HTTPS | 用 Lucky / Nginx 反代，配 Let's Encrypt 证书（DNS 验证可以自动续） |
| 走 Cloudflare | 域名接 CF，开 Full 模式，CF 帮你终结 TLS |
| 只在内网用 | 面板本身只监听 `127.0.0.1`，靠 SSH 隧道访问 |

顺便说一句：**自签证书基本没用**。客户端不信任，浏览器红警告，用户点"继续访问"之后和明文没区别。要么正经证书，要么就别开 HTTPS 装样子。

---

## 二、容易被忽略的

### 代理软件会污染 DDNS

开着 Clash / V2Ray 的 TUN 模式跑 DDNS 脚本，脚本请求"我的公网 IP"时被代理接管，拿回的是**代理出口 IP**。

后果：域名 A 记录指向一台不相干的机器，客户端连过去报 `connection refused`，而你的服务其实好好的。排查起来极其费时——因为我们真的踩过，查了两小时。

```bash
# 防御 1：用国内回显源
ip.3322.net
myip.ipip.net
ddns.oray.com/checkip

# 防御 2：直接写死 IP，不用 DDNS

# 防御 3：代理软件加直连规则
DOMAIN-SUFFIX,example.com,DIRECT
```

### fake-ip 会让 SSH 连错地方

Clash 的 fake-ip 模式会把域名解析成 `198.18.0.x`。如果你用域名 SSH：

```
Connection closed by 198.18.0.83 port 22    ← 这个 IP 根本不是你的服务器
```

同样靠 `DOMAIN-SUFFIX,...,DIRECT` 解决。

### UDP 转发常常忘记配

TCP 转发配好了，UDP 没配——表现是"网站能开，但游戏连不上"。

路由器里 TCP 和 UDP 是**分开的规则**，Minecraft 基岩版（19132）、语音、部分游戏协议都走 UDP。

### 时间不准会让定时任务错位

我们遇到过：`tzutil /g` 显示 `China Standard Time`，看起来完全正常，但系统时钟**偏了 8 小时**——因为 `w32time` 服务是 `Stopped`，从来没同步过。

结果"凌晨 3 点自动重启"实际在**上午 11 点**执行。

```powershell
Get-Service w32time                                    # 必须 Running
w32tm /resync /rediscover                              # 立即校准
```

Linux 上：

```bash
timedatectl status
sudo timedatectl set-ntp true
```

---

## 三、暴露之后的持续维护

| 频率 | 做什么 |
|---|---|
| 每周 | 看一眼 frps / frpc 日志有没有异常登录 |
| 每月 | 检查 frp 有没有新版本（安全修复） |
| 每季度 | 复查一遍开放的端口，关掉不用的 |
| 不定期 | 改密码、轮换 token |

```bash
# 快速自查：现在到底开了哪些端口
sudo ss -tlnp
grep -c "\[\[proxies\]\]" /etc/frp/frpc.toml
```

---

## 四、一句话总结

> 隧道本身是安全的（TLS + token），
> **不安全的是隧道尽头那个服务**。

frp 只负责搬运流量，它不知道你把什么搬上去了。一个没有密码的 qBittorrent WebUI、一个默认口令的路由器管理页、一个 `--privileged` 的 Docker API——这些东西一旦上公网，出事只是时间问题。

**开端口之前先问自己：这个服务本身，敢不敢直接放公网？**
