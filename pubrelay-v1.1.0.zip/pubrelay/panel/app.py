#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Port Panel —— frpc 代理管理 Web UI

跑在内网客户端上，通过浏览器增删启停 frp 端口映射，不用再手改 TOML。

设计要点:
  * 纯标准库，无第三方依赖（NAS 上不用装 Flask）
  * 行级编辑 frpc.toml，保留原有注释、分节与格式
  * 高危端口黑名单，拒绝一键暴露
  * 口令登录 + HttpOnly Cookie，公网暴露也有最小防护
  * 改配置前自动备份，改完异步重启 frpc（不阻断当前 SSH 会话）
"""

import hashlib
import hmac
import json
import os
import re
import secrets
import subprocess
import sys
import threading
import time
import traceback
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

# --------------------------------------------------------------------------
# 配置
# --------------------------------------------------------------------------
FRPC_CONF = os.environ.get("PANEL_FRPC_CONF", "/etc/frp/frpc.toml")
LISTEN_HOST = os.environ.get("PANEL_HOST", "0.0.0.0")
LISTEN_PORT = int(os.environ.get("PANEL_PORT", "2285"))
SERVICE = os.environ.get("PANEL_SERVICE", "frpc")

# 口令：优先读环境变量。没有就随机生成一个并打到日志里，
# 避免"默认口令"这种硬编码被扫描器直接撞开。
_ENV_PW = os.environ.get("PANEL_PASSWORD", "").strip()
if _ENV_PW:
    PASSWORD = _ENV_PW
else:
    PASSWORD = secrets.token_urlsafe(12)
    sys.stderr.write(
        "\n[portpanel] PANEL_PASSWORD 未设置，本次启动使用随机口令: %s\n"
        "[portpanel] 该口令在进程重启后会自动变化，长期使用请通过环境变量固定。\n\n"
        % PASSWORD
    )
    sys.stderr.flush()

# 绝不建议一键开放的端口（仍会显示，但添加时拒绝，除非手动改配置）
DENY_PORTS = {
    21: "FTP 明文口令",
    23: "Telnet 明文",
    111: "rpcbind 信息泄露",
    139: "SMB 勒索病毒首选",
    445: "SMB 高危",
    2049: "NFS 无认证",
    7890: "Clash 代理会被滥用",
    3702: "wsdd2 组播",
    3306: "MySQL 裸奔风险",
    5432: "PostgreSQL 裸奔风险",
    6379: "Redis 无认证",
}

# 保护自身，防止把自己删掉失联
SELF_PORT = LISTEN_PORT

COOKIE_NAME = "pp_session"
COOKIE_VALUE = hmac.new(
    b"portpanel-session", PASSWORD.encode("utf-8"), hashlib.sha256
).hexdigest()

IS_ROOT = hasattr(os, "geteuid") and os.geteuid() == 0

_lock = threading.Lock()


# --------------------------------------------------------------------------
# frpc.toml 解析 / 编辑
# --------------------------------------------------------------------------
RE_PROXY_HEAD = re.compile(r"^\s*(#\s*)?\[\[proxies\]\]\s*$")
RE_TABLE = re.compile(r"^\s*#?\s*\[")
RE_ASSIGN = re.compile(r"^\s*#?\s*([A-Za-z_][\w.]*)\s*=\s*(.+?)\s*$")


def _unquote(v: str) -> str:
    v = v.strip()
    if len(v) >= 2 and v[0] == v[-1] and v[0] in "\"'":
        return v[1:-1]
    return v


def kv(body, key):
    pat = re.compile(r"^\s*#?\s*" + re.escape(key) + r"\s*=\s*(.+?)\s*$")
    for line in body:
        m = pat.match(line)
        if m:
            return _unquote(m.group(1))
    return None


def read_conf():
    try:
        with open(FRPC_CONF, "r", encoding="utf-8") as f:
            return f.read()
    except FileNotFoundError:
        return ""


def parse(text):
    """返回 (blocks, lines)。block = dict(name, localPort, remotePort, enabled, start, end)"""
    lines = text.split("\n")
    blocks = []
    i = 0
    n = len(lines)
    while i < n:
        m = RE_PROXY_HEAD.match(lines[i])
        if not m:
            i += 1
            continue
        start = i
        commented = bool(m.group(1))
        j = i + 1
        while j < n:
            if RE_TABLE.match(lines[j]) and lines[j].strip():
                break
            j += 1
        body = lines[start:j]
        lp = kv(body, "localPort")
        rp = kv(body, "remotePort")
        name = kv(body, "name")
        try:
            lp_i = int(lp) if lp is not None else None
            rp_i = int(rp) if rp is not None else None
        except ValueError:
            lp_i = rp_i = None
        blocks.append(
            {
                "name": name or "",
                "localPort": lp_i,
                "remotePort": rp_i,
                "localIP": kv(body, "localIP") or "127.0.0.1",
                "type": kv(body, "type") or "tcp",
                "enabled": not commented,
                "start": start,
                "end": j,
            }
        )
        i = j
    return blocks, lines


def render_block(name, local_port, remote_port, local_ip="127.0.0.1", ptype="tcp"):
    return [
        "[[proxies]]",
        'name = "%s"' % name,
        'type = "%s"' % ptype,
        'localIP = "%s"' % local_ip,
        "localPort = %d" % local_port,
        "remotePort = %d" % remote_port,
    ]


def backup(text):
    stamp = int(time.time())
    path = "%s.bak.%d" % (FRPC_CONF, stamp)
    try:
        with open(path, "w", encoding="utf-8") as f:
            f.write(text)
        # 只留最近 20 份
        folder = os.path.dirname(FRPC_CONF)
        baks = sorted(
            [x for x in os.listdir(folder) if x.startswith(os.path.basename(FRPC_CONF) + ".bak.")],
            key=lambda x: os.path.getmtime(os.path.join(folder, x)),
        )
        for old in baks[:-20]:
            try:
                os.remove(os.path.join(folder, old))
            except OSError:
                pass
    except OSError:
        pass
    return path


def write_conf(text):
    tmp = FRPC_CONF + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        f.write(text)
    os.chmod(tmp, 0o644)
    os.replace(tmp, FRPC_CONF)


# --------------------------------------------------------------------------
# frpc 控制
# --------------------------------------------------------------------------
def _run(cmd):
    if IS_ROOT:
        return subprocess.run(cmd, capture_output=True, text=True, timeout=15)
    return subprocess.run(["sudo", "-n"] + cmd, capture_output=True, text=True, timeout=15)


def frpc_active():
    r = _run(["systemctl", "is-active", SERVICE])
    return (r.stdout or "").strip() or "unknown"


def restart_frpc():
    """异步重启，避免当前 HTTP 请求被 frpc 断连拖死。"""
    cmd = ["systemctl", "restart", SERVICE]
    if not IS_ROOT:
        cmd = ["sudo", "-n"] + cmd

    def _bg():
        try:
            subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
        except Exception:
            pass

    threading.Thread(target=_bg, daemon=True).start()


# --------------------------------------------------------------------------
# 本机端口扫描
# --------------------------------------------------------------------------
def scan_listen_ports():
    cmd = ["ss", "-tlnp"]
    if not IS_ROOT:
        cmd = ["sudo", "-n"] + cmd
    try:
        out = subprocess.run(cmd, capture_output=True, text=True, timeout=10).stdout
    except Exception:
        return []
    found = {}
    for line in out.splitlines():
        m = re.search(r':(\d+)\s+\S+\s+users:\(\("([^"]+)",pid=(\d+)', line)
        if not m:
            continue
        port = int(m.group(1))
        proc, pid = m.group(2), int(m.group(3))
        if port in found:
            if proc not in found[port]["proc"]:
                found[port]["proc"].append(proc)
        else:
            found[port] = {"port": port, "proc": [proc], "pid": pid}
    return sorted(found.values(), key=lambda x: x["port"])


# --------------------------------------------------------------------------
# 业务动作
# --------------------------------------------------------------------------
def state():
    text = read_conf()
    blocks, _ = parse(text)

    enabled = []
    for b in blocks:
        if not b["enabled"]:
            continue
        item = dict(b)
        item["self"] = (b["localPort"] == SELF_PORT)
        item["risky"] = b["localPort"] in DENY_PORTS or b["remotePort"] in DENY_PORTS
        enabled.append(item)

    disabled = []
    for b in blocks:
        if b["enabled"]:
            continue
        item = dict(b)
        item["risky"] = b["localPort"] in DENY_PORTS or b["remotePort"] in DENY_PORTS
        disabled.append(item)

    mapped_local = {b["localPort"] for b in blocks if b["enabled"]}
    ports = []
    for p in scan_listen_ports():
        d = dict(p)
        d["mapped"] = p["port"] in mapped_local
        d["deny"] = DENY_PORTS.get(p["port"])
        ports.append(d)

    server_addr = ""
    m = re.search(r'^\s*serverAddr\s*=\s*"?([^"\n]+)"?', text, re.M)
    if m:
        server_addr = m.group(1).strip()

    return {
        "ok": True,
        "frpc": frpc_active(),
        "serverAddr": server_addr,
        "panelPort": SELF_PORT,
        "proxies": sorted(enabled, key=lambda x: x["localPort"] or 0),
        "disabled": disabled,
        "ports": ports,
        "bakCount": len([x for x in os.listdir(os.path.dirname(FRPC_CONF) or ".")
                         if x.startswith(os.path.basename(FRPC_CONF) + ".bak.")]),
    }


def add_proxy(local_port, remote_port, name, local_ip="127.0.0.1", ptype="tcp",
              do_restart=True):
    if not (1 <= local_port <= 65535 and 1 <= remote_port <= 65535):
        return {"ok": False, "error": "端口超出范围"}
    if ptype not in ("tcp", "udp"):
        return {"ok": False, "error": "协议只能是 tcp 或 udp"}
    if local_port in DENY_PORTS:
        return {"ok": False, "error": "本地端口 %d 属高危（%s），已拒绝" % (local_port, DENY_PORTS[local_port])}
    if not re.match(r"^[A-Za-z0-9_-]{1,64}$", name):
        return {"ok": False, "error": "名称只能包含字母数字下划线和短横线，长度 1-64"}
    if local_ip not in ("127.0.0.1", "localhost"):
        return {"ok": False, "error": "localIP 仅允许 127.0.0.1"}

    text = read_conf()
    blocks, lines = parse(text)
    for b in blocks:
        if b["name"] == name:
            return {"ok": False, "error": "已存在同名代理: %s" % name}
        if b["enabled"] and b["remotePort"] == remote_port and b["type"] == ptype:
            return {"ok": False, "error": "公网 %s/%d 已被 %s 占用" % (ptype, remote_port, b["name"])}

    body = render_block(name, local_port, remote_port, local_ip, ptype)
    # 插到文件末尾，前面留空行
    while lines and lines[-1].strip() == "":
        lines.pop()
    new_text = "\n".join(lines) + "\n\n" + "\n".join(body) + "\n"

    backup(text)
    write_conf(new_text)
    if do_restart:
        restart_frpc()
    return {"ok": True, "msg": "已添加 %s（%s %d → %d）" % (name, ptype.upper(), local_port, remote_port)}


# Minecraft 联机常用端口：Java 版 TCP，基岩版 UDP
MC_PRESETS = [
    (25565, 25565, "tcp", "mc-java-25565"),
    (25566, 25566, "tcp", "mc-java-25566"),
    (19132, 19132, "udp", "mc-bedrock-19132"),
    (19133, 19133, "udp", "mc-bedrock-19133"),
]


def preset_mc():
    blocks, _ = parse(read_conf())
    have = {(b["remotePort"], b["type"]) for b in blocks if b["enabled"]}
    added, skipped, failed = [], [], []
    for lp, rp, pt, nm in MC_PRESETS:
        if (rp, pt) in have:
            skipped.append("%s/%d" % (pt.upper(), rp))
            continue
        r = add_proxy(lp, rp, nm, ptype=pt, do_restart=False)
        if r.get("ok"):
            added.append("%s/%d" % (pt.upper(), rp))
        else:
            failed.append("%s/%d %s" % (pt.upper(), rp, r.get("error")))
    if added:
        restart_frpc()

    parts = []
    if added:
        parts.append("已开启 " + "、".join(added))
    if skipped:
        parts.append("已存在跳过 " + "、".join(skipped))
    if failed:
        parts.append("失败 " + "; ".join(failed))
    return {
        "ok": bool(added) or not failed,
        "msg": "，".join(parts) if parts else "无需变更",
        "added": added,
        "skipped": skipped,
        "failed": failed,
    }



def delete_proxy(name):
    text = read_conf()
    blocks, lines = parse(text)
    target = next((b for b in blocks if b["name"] == name), None)
    if not target:
        return {"ok": False, "error": "未找到代理: %s" % name}
    if target["enabled"] and target["localPort"] == SELF_PORT:
        return {"ok": False, "error": "该代理是本面板自身通道，禁止删除"}

    start, end = target["start"], target["end"]
    if start > 0 and lines[start - 1].strip().startswith("#") and "proxy" in lines[start - 1].lower():
        start -= 1
    del lines[start:end]
    new_text = "\n".join(lines)
    if not new_text.endswith("\n"):
        new_text += "\n"

    backup(text)
    write_conf(new_text)
    restart_frpc()
    return {"ok": True, "msg": "已删除 %s，frpc 重启中" % name}


def set_enabled(name, enabled):
    text = read_conf()
    blocks, lines = parse(text)
    target = next((b for b in blocks if b["name"] == name), None)
    if not target:
        return {"ok": False, "error": "未找到代理: %s" % name}
    if target["enabled"] == enabled:
        return {"ok": True, "msg": "状态未变化"}
    if enabled and target["localPort"] in DENY_PORTS:
        return {"ok": False, "error": "本地端口 %d 属高危（%s）" % (target["localPort"], DENY_PORTS[target["localPort"]])}

    out = []
    for idx, line in enumerate(lines):
        if target["start"] <= idx < target["end"]:
            if enabled:
                out.append(re.sub(r"^(\s*)#{1,2}\s?", r"\1", line))
            else:
                stripped = line.lstrip()
                indent = line[: len(line) - len(stripped)]
                out.append(indent + "#" + stripped if stripped else line)
        else:
            out.append(line)

    backup(text)
    write_conf("\n".join(out))
    restart_frpc()
    return {"ok": True, "msg": "%s 已%s，frpc 重启中" % (name, "启用" if enabled else "停用")}


# --------------------------------------------------------------------------
# HTML
# --------------------------------------------------------------------------
PAGE = r"""<!DOCTYPE html>
<html lang="zh-CN">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Port Panel 端口面板</title>
<style>
:root{
  --bg:#0e1116; --panel:#161b23; --panel2:#1c222c; --line:#2a323f;
  --txt:#e6edf3; --dim:#8b98a8; --acc:#4c8dff; --ok:#3fb950; --warn:#d29922; --bad:#f85149;
}
*{box-sizing:border-box}
body{margin:0;background:var(--bg);color:var(--txt);
  font:14px/1.6 -apple-system,"Segoe UI","PingFang SC","Microsoft YaHei",sans-serif}
a{color:var(--acc)}
.wrap{max-width:1080px;margin:0 auto;padding:24px 18px 60px}
header{display:flex;align-items:center;gap:14px;flex-wrap:wrap;margin-bottom:22px}
h1{font-size:19px;margin:0;font-weight:600;letter-spacing:.5px}
.dot{width:8px;height:8px;border-radius:50%;display:inline-block;margin-right:6px}
.badge{font-size:12px;color:var(--dim);background:var(--panel2);border:1px solid var(--line);
  padding:2px 9px;border-radius:20px}
.spacer{flex:1}
button{font:inherit;cursor:pointer;border-radius:8px;border:1px solid var(--line);
  background:var(--panel2);color:var(--txt);padding:7px 14px;transition:.15s}
button:hover{border-color:#3d4a5c;background:#232b36}
button.primary{background:var(--acc);border-color:var(--acc);color:#fff}
button.primary:hover{background:#3c7bed}
button.danger:hover{border-color:var(--bad);color:var(--bad)}
button:disabled{opacity:.5;cursor:not-allowed}
.card{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:16px 18px;margin-bottom:18px}
.card h2{font-size:14px;margin:0 0 14px;font-weight:600;color:var(--dim);
  text-transform:uppercase;letter-spacing:1px}
.grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(232px,1fr));gap:10px}
.pr{background:var(--panel2);border:1px solid var(--line);border-radius:10px;padding:11px 13px;
  display:flex;align-items:center;gap:10px}
.pr .nm{font-weight:600;font-size:13px;word-break:break-all}
.pr .pt{font-size:12px;color:var(--dim);font-variant-numeric:tabular-nums}
.pr .act{margin-left:auto;display:flex;gap:6px}
.iconbtn{border:none;background:transparent;color:var(--dim);padding:4px 6px;border-radius:6px;font-size:15px;line-height:1}
.iconbtn:hover{background:#2c3542;color:var(--txt)}
.iconbtn.del:hover{color:var(--bad)}
.tag{font-size:11px;padding:1px 6px;border-radius:4px;border:1px solid var(--line);color:var(--dim)}
.tag.self{border-color:#2d4a7a;color:#7aa9ff;background:#16233a}
.tag.risk{border-color:#5a3a1a;color:var(--warn);background:#251b0f}
form.row{display:flex;gap:10px;flex-wrap:wrap;align-items:flex-end}
label{display:block;font-size:12px;color:var(--dim);margin-bottom:5px}
input[type=text],input[type=number],input[type=password],select{
  font:inherit;background:#0b0e13;border:1px solid var(--line);color:var(--txt);
  border-radius:8px;padding:8px 11px;width:132px;outline:none}
select{width:84px;cursor:pointer}
input:focus,select:focus{border-color:var(--acc)}
input.wide{width:190px}
.ports{display:grid;grid-template-columns:repeat(auto-fill,minmax(168px,1fr));gap:8px;max-height:330px;overflow:auto}
.pt2{background:var(--panel2);border:1px solid var(--line);border-radius:8px;padding:8px 10px;
  display:flex;align-items:center;gap:8px;font-size:12px}
.pt2 b{font-variant-numeric:tabular-nums;font-size:13px}
.pt2 .svc{color:var(--dim);overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.pt2.on{border-color:#1f4d2a;background:#12210f}
.mcbar{display:flex;align-items:center;gap:12px;flex-wrap:wrap}
.mcbar .txt{font-size:12px;color:var(--dim);flex:1;min-width:200px}
.muted{color:var(--dim);font-size:12px}
.toast{position:fixed;left:50%;bottom:26px;transform:translateX(-50%);background:#1f2733;
  border:1px solid var(--line);border-radius:10px;padding:11px 20px;font-size:13px;
  box-shadow:0 8px 30px rgba(0,0,0,.5);opacity:0;transition:.25s;pointer-events:none;max-width:90vw}
.toast.show{opacity:1;transform:translateX(-50%) translateY(-6px)}
.toast.err{border-color:var(--bad);color:#ffb3ae}
.toast.ok{border-color:#2a5c33}
#login{position:fixed;inset:0;background:var(--bg);display:flex;align-items:center;
  justify-content:center;z-index:20}
#login .box{background:var(--panel);border:1px solid var(--line);border-radius:14px;
  padding:30px 28px;width:320px;text-align:center}
#login h1{margin:0 0 6px}
#login input{width:100%;margin:16px 0 12px}
#login button{width:100%}
.hide{display:none!important}
.empty{color:var(--dim);font-size:13px;padding:6px 0}
</style>
</head>
<body>

<div id="login">
  <div class="box">
    <h1>Port Panel 端口面板</h1>
    <div class="muted">frpc 端口映射控制台</div>
    <input type="password" id="pw" placeholder="访问口令" autocomplete="current-password">
    <button class="primary" id="loginBtn">进入</button>
    <div class="muted" id="loginMsg" style="margin-top:10px;height:16px"></div>
  </div>
</div>

<div class="wrap hide" id="app">
  <header>
    <h1>Port Panel 端口面板</h1>
    <span class="badge" id="frpcBadge"><span class="dot" style="background:var(--dim)"></span>—</span>
    <span class="badge" id="addrBadge">—</span>
    <div class="spacer"></div>
    <button id="restartBtn">重启 frpc</button>
    <button id="logoutBtn">退出</button>
  </header>

  <div class="card">
    <h2>Minecraft 联机</h2>
    <div class="mcbar">
      <button class="primary" id="mcBtn">一键开启 MC 端口</button>
      <div class="txt">Java 版 25565 / 25566（TCP），基岩版 19132 / 19133（UDP）。已存在的会自动跳过。</div>
    </div>
  </div>

  <div class="card">
    <h2>新增映射</h2>
    <form class="row" id="addForm">
      <div><label>协议</label><select id="pt"><option value="tcp">TCP</option><option value="udp">UDP</option></select></div>
      <div><label>NAS 本地端口</label><input type="number" id="lp" min="1" max="65535" placeholder="8090"></div>
      <div><label>公网端口</label><input type="number" id="rp" min="1" max="65535" placeholder="留空=同号"></div>
      <div><label>名称</label><input type="text" id="nm" class="wide" placeholder="留空自动生成"></div>
      <button class="primary" type="submit">添加并生效</button>
    </form>
    <div class="muted" style="margin-top:10px">公网访问方式：<b>9188888.cn:公网端口</b>。高危端口（21/445/2049/7890 等）已禁止一键开放。</div>
  </div>

  <div class="card">
    <h2>已启用映射 <span class="muted" id="enabledCount"></span></h2>
    <div class="grid" id="list"></div>
  </div>

  <div class="card hide" id="disCard">
    <h2>已停用（配置中已被注释）</h2>
    <div class="grid" id="disList"></div>
  </div>

  <div class="card">
    <h2>NAS 正在监听的端口 <span class="muted" id="scanHint"></span></h2>
    <div class="ports" id="ports"></div>
  </div>
</div>

<div class="toast" id="toast"></div>

<script>
const $ = s => document.querySelector(s);
let S = null;

function toast(msg, kind){
  const t = $('#toast');
  t.textContent = msg;
  t.className = 'toast show ' + (kind||'');
  clearTimeout(t._h);
  t._h = setTimeout(()=>{ t.className='toast'; }, 3200);
}

async function api(path, body){
  const r = await fetch(path, {
    method: body ? 'POST' : 'GET',
    headers: {'Content-Type':'application/json'},
    credentials: 'same-origin',
    body: body ? JSON.stringify(body) : undefined
  });
  if (r.status === 401) { $('#login').classList.remove('hide'); $('#app').classList.add('hide'); throw new Error('请登录'); }
  return await r.json();
}

function esc(s){ return String(s==null?'':s).replace(/[&<>"']/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }

function render(){
  const b = $('#frpcBadge');
  const active = S.frpc === 'active';
  b.innerHTML = '<span class="dot" style="background:' + (active?'var(--ok)':'var(--bad)') + '"></span>' + esc(S.frpc);
  $('#addrBadge').textContent = '中转 ' + (S.serverAddr || '?');

  $('#enabledCount').textContent = '(' + S.proxies.length + ')';
  $('#list').innerHTML = S.proxies.length ? S.proxies.map(p => `
    <div class="pr">
      <div>
        <div class="nm">${esc(p.name)}</div>
        <div class="pt">${(p.type||'tcp').toUpperCase()} · 本地 ${p.localPort} → 公网 ${p.remotePort}</div>
      </div>
      <div class="act">
        ${p.self ? '<span class="tag self">本面板</span>' : ''}
        ${p.risky && !p.self ? '<span class="tag risk">高危</span>' : ''}
        ${p.self ? '' : `<button class="iconbtn del" title="删除" onclick="del('${esc(p.name)}')">✕</button>`}
      </div>
    </div>`).join('') : '<div class="empty">暂无映射</div>';

  $('#disCard').classList.toggle('hide', !S.disabled.length);
  $('#disList').innerHTML = S.disabled.map(p => `
    <div class="pr">
      <div>
        <div class="nm">${esc(p.name)}</div>
        <div class="pt">${(p.type||'tcp').toUpperCase()} · 本地 ${p.localPort} → 公网 ${p.remotePort}</div>
      </div>
      <div class="act">
        <button class="iconbtn" title="启用" onclick="toggle('${esc(p.name)}',true)">▶</button>
        <button class="iconbtn del" title="删除" onclick="del('${esc(p.name)}')">✕</button>
      </div>
    </div>`).join('');

  const mapped = S.ports.filter(p => p.mapped).length;
  $('#scanHint').textContent = '共 ' + S.ports.length + ' 个，已映射 ' + mapped + ' 个';
  $('#ports').innerHTML = S.ports.map(p => `
    <div class="pt2 ${p.mapped?'on':''}">
      <b>${p.port}</b>
      <span class="svc" title="${esc(p.proc.join(', '))}">${esc(p.proc.join(','))}</span>
      ${p.mapped
        ? '<span class="tag" style="margin-left:auto">已开</span>'
        : `<button class="iconbtn" style="margin-left:auto" title="${p.deny?('高危：'+p.deny):'添加映射'}"
             ${p.deny?'disabled':''} onclick="quick(${p.port})">+</button>`}
    </div>`).join('');
}

async function load(){
  S = await api('/api/state');
  $('#login').classList.add('hide');
  $('#app').classList.remove('hide');
  render();
}

async function del(name){
  if (!confirm('删除映射 ' + name + ' ？公网将立刻无法访问该端口。')) return;
  const r = await api('/api/del', {name});
  toast(r.ok ? r.msg : r.error, r.ok ? 'ok' : 'err');
  if (r.ok) setTimeout(load, 1600);
}
async function toggle(name, on){
  const r = await api('/api/toggle', {name, enabled: on});
  toast(r.ok ? r.msg : r.error, r.ok ? 'ok' : 'err');
  if (r.ok) setTimeout(load, 1600);
}
function quick(port){
  $('#lp').value = port;
  $('#rp').value = port;
  $('#nm').value = 'nas-' + port;
  $('#lp').scrollIntoView({behavior:'smooth', block:'center'});
  $('#lp').focus();
}
$('#addForm').addEventListener('submit', async e => {
  e.preventDefault();
  const lp = parseInt($('#lp').value, 10);
  const rp = parseInt($('#rp').value || $('#lp').value, 10);
  const nm = ($('#nm').value || ('nas-' + lp)).trim();
  const pt = $('#pt').value;
  if (!lp) { toast('请填写本地端口', 'err'); return; }
  const r = await api('/api/add', {localPort: lp, remotePort: rp, name: nm, type: pt});
  toast(r.ok ? r.msg : r.error, r.ok ? 'ok' : 'err');
  if (r.ok) { $('#addForm').reset(); setTimeout(load, 1800); }
});
$('#mcBtn').addEventListener('click', async () => {
  if (!confirm('一键开启 Minecraft 联机端口？\n\nJava 版 25565 / 25566（TCP）\n基岩版 19132 / 19133（UDP）\n\n已存在的会自动跳过。')) return;
  const r = await api('/api/preset_mc', {});
  toast(r.ok ? r.msg : (r.msg || r.error), r.ok ? 'ok' : 'err');
  setTimeout(load, 2400);
});
$('#restartBtn').addEventListener('click', async () => {
  if (!confirm('重启 frpc？所有公网映射会闪断约 1-3 秒。')) return;
  const r = await api('/api/restart', {});
  toast(r.ok ? r.msg : r.error, r.ok ? 'ok' : 'err');
  setTimeout(load, 2500);
});
$('#logoutBtn').addEventListener('click', async () => {
  await api('/api/logout', {});
  location.reload();
});
$('#lp').addEventListener('input', () => {
  if (!$('#rp').value) $('#rp').placeholder = $('#lp').value || '留空=同号';
});
$('#loginBtn').addEventListener('click', async () => {
  const r = await api('/api/login', {password: $('#pw').value});
  if (r.ok) { load().catch(()=>{}); }
  else { $('#loginMsg').textContent = r.error || '口令错误'; }
});
$('#pw').addEventListener('keydown', e => { if (e.key === 'Enter') $('#loginBtn').click(); });

load().catch(()=>{});
setInterval(()=>{ if (S && !$('#app').classList.contains('hide')) load().catch(()=>{}); }, 8000);
</script>
</body>
</html>
"""


# --------------------------------------------------------------------------
# HTTP 处理
# --------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "DoudouPortPanel/1.0"
    protocol_version = "HTTP/1.1"

    def log_message(self, fmt, *args):
        sys.stderr.write("%s - %s\n" % (self.address_string(), fmt % args))

    # ---- 工具 ----
    def _send(self, code, body, ctype="application/json; charset=utf-8", extra=None):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False)
        raw = body.encode("utf-8") if isinstance(body, str) else body
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(raw)))
        self.send_header("Cache-Control", "no-store")
        self.send_header("X-Content-Type-Options", "nosniff")
        for k, v in (extra or []):
            self.send_header(k, v)
        self.end_headers()
        try:
            self.wfile.write(raw)
        except (BrokenPipeError, ConnectionResetError):
            pass

    def _authed(self):
        raw = self.headers.get("Cookie")
        if not raw:
            return False
        c = SimpleCookie()
        try:
            c.load(raw)
        except Exception:
            return False
        morsel = c.get(COOKIE_NAME)
        return bool(morsel) and hmac.compare_digest(morsel.value, COOKIE_VALUE)

    def _body(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            if n <= 0 or n > 65536:
                return {}
            return json.loads(self.rfile.read(n).decode("utf-8") or "{}")
        except Exception:
            return {}

    # ---- 路由 ----
    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/":
            return self._send(200, PAGE, "text/html; charset=utf-8")
        if path == "/api/state":
            if not self._authed():
                return self._send(401, {"ok": False, "error": "未登录"})
            try:
                with _lock:
                    return self._send(200, state())
            except Exception:
                return self._send(500, {"ok": False, "error": traceback.format_exc(limit=3)})
        if path == "/healthz":
            return self._send(200, {"ok": True})
        return self._send(404, {"ok": False, "error": "not found"})

    def do_POST(self):
        path = self.path.split("?")[0]
        data = self._body()

        if path == "/api/login":
            pw = str(data.get("password") or "")
            if hmac.compare_digest(pw, PASSWORD):
                cookie = "%s=%s; Path=/; HttpOnly; SameSite=Strict; Max-Age=2592000" % (
                    COOKIE_NAME, COOKIE_VALUE)
                return self._send(200, {"ok": True}, extra=[("Set-Cookie", cookie)])
            time.sleep(0.6)
            return self._send(200, {"ok": False, "error": "口令错误"})

        if path == "/api/logout":
            return self._send(200, {"ok": True}, extra=[
                ("Set-Cookie", "%s=; Path=/; Max-Age=0" % COOKIE_NAME)])

        if not self._authed():
            return self._send(401, {"ok": False, "error": "未登录"})

        try:
            with _lock:
                if path == "/api/add":
                    lpv = int(data.get("localPort") or 0)
                    rpv = int(data.get("remotePort") or lpv)
                    nm = str(data.get("name") or ("nas-%d" % lpv))
                    pt = str(data.get("type") or "tcp").lower()
                    return self._send(200, add_proxy(lpv, rpv, nm, ptype=pt))

                if path == "/api/preset_mc":
                    return self._send(200, preset_mc())

                if path == "/api/del":
                    return self._send(200, delete_proxy(str(data.get("name") or "")))

                if path == "/api/toggle":
                    return self._send(200, set_enabled(
                        str(data.get("name") or ""), bool(data.get("enabled"))))

                if path == "/api/restart":
                    restart_frpc()
                    return self._send(200, {"ok": True, "msg": "frpc 重启中"})
        except Exception:
            return self._send(500, {"ok": False, "error": traceback.format_exc(limit=3)})

        return self._send(404, {"ok": False, "error": "not found"})


# --------------------------------------------------------------------------
def main():
    srv = ThreadingHTTPServer((LISTEN_HOST, LISTEN_PORT), Handler)
    srv.daemon_threads = True
    sys.stderr.write(
        "[portpanel] listening on %s:%d  conf=%s  root=%s  pwd=%s***\n"
        % (LISTEN_HOST, LISTEN_PORT, FRPC_CONF, IS_ROOT, PASSWORD[:3])
    )
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


if __name__ == "__main__":
    main()
