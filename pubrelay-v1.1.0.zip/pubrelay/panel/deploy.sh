#!/bin/bash
# ============================================================
#  Port Panel 一键部署 (Linux)
#
#  用法:
#    sudo PANEL_PASSWORD='你的口令' bash deploy.sh
#    sudo PANEL_PORT=2285 PANEL_PASSWORD='...' bash deploy.sh
#
#  可选环境变量:
#    PANEL_PORT        面板监听端口，默认 2285
#    PANEL_PASSWORD    登录口令；不设置会随机生成
#    PANEL_FRPC_CONF   frpc 配置文件路径，默认 /etc/frp/frpc.toml
#    PANEL_SERVICE     要重启的 systemd 服务名，默认 frpc
#    SKIP_FRP_MAP      =1 时不自动给 frpc 加面板自身的公网映射
# ============================================================
set -e

APP_DIR=/opt/portpanel
PANEL_PORT="${PANEL_PORT:-2285}"
PANEL_FRPC_CONF="${PANEL_FRPC_CONF:-/etc/frp/frpc.toml}"
PANEL_SERVICE="${PANEL_SERVICE:-frpc}"
PANEL_PASSWORD="${PANEL_PASSWORD:-}"

if [ -z "$PANEL_PASSWORD" ]; then
  PANEL_PASSWORD=$(head -c 24 /dev/urandom | base64 | tr -d '/+=' | head -c 16)
  echo "[!] 未提供 PANEL_PASSWORD，已生成：$PANEL_PASSWORD"
fi

SRC="$(cd "$(dirname "$0")" && pwd)/app.py"
[ -f "$SRC" ] || { echo "找不到 app.py，请在 panel/ 目录下执行"; exit 1; }

echo "==> 1/5 安装文件到 $APP_DIR"
mkdir -p "$APP_DIR"
install -m 755 -o root -g root "$SRC" "$APP_DIR/app.py"

echo "==> 2/5 写入 systemd unit"
cat > /etc/systemd/system/portpanel.service <<UNIT
[Unit]
Description=Port Panel (frpc manager web ui)
After=network-online.target ${PANEL_SERVICE}.service
Wants=network-online.target

[Service]
Type=simple
User=root
Environment=PANEL_PORT=${PANEL_PORT}
Environment=PANEL_PASSWORD=${PANEL_PASSWORD}
Environment=PANEL_FRPC_CONF=${PANEL_FRPC_CONF}
Environment=PANEL_SERVICE=${PANEL_SERVICE}
ExecStart=/usr/bin/python3 ${APP_DIR}/app.py
Restart=always
RestartSec=3
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable portpanel >/dev/null 2>&1 || true

echo "==> 3/5 给 frpc 追加面板公网映射"
if [ "${SKIP_FRP_MAP:-0}" = "1" ]; then
  echo "    SKIP_FRP_MAP=1，跳过"
elif [ ! -f "$PANEL_FRPC_CONF" ]; then
  echo "    [!] 找不到 $PANEL_FRPC_CONF，跳过"
elif grep -q "name = \"portpanel-${PANEL_PORT}\"" "$PANEL_FRPC_CONF"; then
  echo "    已存在，跳过"
else
  cp -a "$PANEL_FRPC_CONF" "${PANEL_FRPC_CONF}.bak.$(date +%s)"
  cat >> "$PANEL_FRPC_CONF" <<FRP

# 端口管理面板 (Port Panel)
[[proxies]]
name = "portpanel-${PANEL_PORT}"
type = "tcp"
localIP = "127.0.0.1"
localPort = ${PANEL_PORT}
remotePort = ${PANEL_PORT}
FRP
  echo "    已追加 portpanel-${PANEL_PORT}"
fi

echo "==> 4/5 启动面板"
systemctl restart portpanel
sleep 1.5
systemctl is-active portpanel || true

echo "==> 5/5 异步重启 ${PANEL_SERVICE}（避免断掉当前 SSH 隧道）"
if systemctl list-unit-files | grep -q "^${PANEL_SERVICE}.service"; then
  systemd-run --no-block --unit="frpc-reload-$(date +%s)" systemctl restart "$PANEL_SERVICE" >/dev/null 2>&1 \
    || nohup systemctl restart "$PANEL_SERVICE" >/dev/null 2>&1 &
else
  echo "    未找到 ${PANEL_SERVICE}.service，跳过"
fi

sleep 0.5
echo
echo "============================================"
echo " 完成。访问地址： http://<本机IP>:${PANEL_PORT}"
echo " 登录口令： ${PANEL_PASSWORD}"
echo " 日志查看： journalctl -u portpanel -f"
echo "============================================"
